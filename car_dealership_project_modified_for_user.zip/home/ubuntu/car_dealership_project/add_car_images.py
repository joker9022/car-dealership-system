import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.main import app, db
from src.models.car import Car, CarImage

def add_car_images():
    with app.app_context():
        # إضافة صور للسيارات
        cars = Car.query.all()
        
        for car in cars:
            # التحقق من وجود صور للسيارة
            existing_image = CarImage.query.filter_by(car_id=car.id).first()
            if not existing_image:
                # إضافة صورة بناءً على الموديل
                if 'كامري' in car.model.model_name:
                    image_url = '/static/images/toyota_camry.jpg'
                elif 'التيما' in car.model.model_name:
                    image_url = '/static/images/nissan_altima.jpg'
                elif 'سيفيك' in car.model.model_name:
                    image_url = '/static/images/honda_civic.jpg'
                else:
                    image_url = '/static/images/default_car.jpg'
                
                car_image = CarImage(car_id=car.id, image_url=image_url, is_primary=True)
                db.session.add(car_image)
        
        db.session.commit()
        print("تم إضافة صور السيارات بنجاح!")

if __name__ == '__main__':
    add_car_images()

