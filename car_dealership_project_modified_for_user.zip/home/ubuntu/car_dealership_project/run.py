import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.main import app

if __name__ == '__main__':
    print("بدء تشغيل خادم معرض السيارات...")
    print("يمكنك الوصول للموقع عبر: http://localhost:5000")
    print("للدخول كمسؤول: اسم المستخدم = admin، كلمة المرور = admin123")
    print("اضغط Ctrl+C لإيقاف الخادم")
    app.run(debug=True, host='0.0.0.0', port=5000)

