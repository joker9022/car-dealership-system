import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import app, db
from src.models.user import User
from src.models.car import Brand, Model, Car
from werkzeug.security import generate_password_hash

def init_database():
    """تهيئة قاعدة البيانات بالبيانات الأولية"""
    with app.app_context():
        # إنشاء الجداول
        db.create_all()
        
        # إنشاء حساب المسؤول إذا لم يكن موجوداً
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@cardealership.com',
                password='admin123',
                is_admin=True,
                first_name='مدير',
                last_name='النظام'
            )
            db.session.add(admin)
            print("تم إنشاء حساب المسؤول")
        
        # إضافة بعض العلامات التجارية الأولية
        brands_data = [
            {'brand_name': 'تويوتا', 'name_en': 'Toyota'},
            {'brand_name': 'نيسان', 'name_en': 'Nissan'},
            {'brand_name': 'هوندا', 'name_en': 'Honda'},
            {'brand_name': 'مرسيدس', 'name_en': 'Mercedes'},
            {'brand_name': 'بي إم دبليو', 'name_en': 'BMW'},
            {'brand_name': 'أودي', 'name_en': 'Audi'},
            {'brand_name': 'فولكس واجن', 'name_en': 'Volkswagen'},
            {'brand_name': 'هيونداي', 'name_en': 'Hyundai'},
            {'brand_name': 'كيا', 'name_en': 'Kia'},
            {'brand_name': 'فورد', 'name_en': 'Ford'}
        ]
        
        for brand_data in brands_data:
            existing_brand = Brand.query.filter_by(brand_name=brand_data['brand_name']).first()
            if not existing_brand:
                brand = Brand(
                    brand_name=brand_data['brand_name'],
                    name=brand_data['brand_name'],
                    name_en=brand_data['name_en']
                )
                db.session.add(brand)
                print(f"تم إضافة العلامة التجارية: {brand_data['brand_name']}")
        
        # حفظ التغييرات
        db.session.commit()
        print("تم تهيئة قاعدة البيانات بنجاح")

if __name__ == '__main__':
    init_database()

