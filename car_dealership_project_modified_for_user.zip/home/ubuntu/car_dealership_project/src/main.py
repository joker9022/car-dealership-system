import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, render_template, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bootstrap import Bootstrap
from datetime import datetime

# تهيئة تطبيق Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-this-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# تهيئة قاعدة البيانات
db = SQLAlchemy(app)

# تهيئة Bootstrap
bootstrap = Bootstrap(app)

# تهيئة مدير تسجيل الدخول
login_manager = LoginManager(app)
login_manager.login_view = 'auth.login'
login_manager.login_message = 'يرجى تسجيل الدخول للوصول إلى هذه الصفحة.'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    from src.models.user import User
    return User.query.get(int(user_id))

# معالج الأخطاء
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

# تهيئة متغيرات عامة للقوالب
@app.context_processor
def inject_now():
    return {'now': datetime.utcnow()}

# استيراد النماذج بعد تهيئة db لتجنب الاستيراد الدائري
with app.app_context():
    from src.models.user import User, Favorite
    from src.models.car import Brand, Model, Car, CarImage
    from src.models.inquiry import Inquiry, Appointment, Article

    # استيراد وتسجيل المسارات
    from src.routes.main import main
    from src.routes.cars import cars
    from src.routes.auth import auth
    from src.routes.admin import admin

    app.register_blueprint(main)
    app.register_blueprint(cars, url_prefix='/cars')
    app.register_blueprint(auth, url_prefix='/auth')
    app.register_blueprint(admin, url_prefix='/admin')



print(f"Flask instance path: {app.instance_path}")
print(f"SQLALCHEMY_DATABASE_URI: {app.config['SQLALCHEMY_DATABASE_URI']}")


