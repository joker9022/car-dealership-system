from src.main import db
from datetime import datetime

class Inquiry(db.Model):
    """نموذج بيانات الاستفسارات"""
    __tablename__ = 'inquiries'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # يمكن أن يكون فارغاً للزوار
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(20))
    message = db.Column(db.Text, nullable=False)
    subject = db.Column(db.String(256))  # للتوافق مع create_db.py
    date_submitted = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)  # للتوافق مع create_db.py
    status = db.Column(db.String(20), default='جديد')  # جديد، قيد المعالجة، مغلق
    
    # العلاقات
    user = db.relationship('User', backref=db.backref('inquiries', lazy='dynamic', cascade='all, delete-orphan'))
    car = db.relationship('Car', backref=db.backref('inquiries', lazy='dynamic', cascade='all, delete-orphan'))
    
    def __init__(self, car_id=None, name=None, email=None, phone=None, message=None, user_id=None, status='جديد', subject=None):
        self.car_id = car_id
        self.name = name
        self.email = email
        self.phone = phone
        self.message = message
        self.subject = subject
        self.user_id = user_id
        self.status = status
        self.created_at = datetime.utcnow()
        self.date_submitted = datetime.utcnow()
    
    def __repr__(self):
        return f'<Inquiry {self.id} for Car {self.car_id}>'


class Appointment(db.Model):
    """نموذج بيانات المواعيد"""
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # يمكن أن يكون فارغاً للزوار
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    preferred_date = db.Column(db.Date, nullable=False)
    preferred_time = db.Column(db.String(20), nullable=False)
    notes = db.Column(db.Text)
    date_submitted = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='مطلوب')  # مطلوب، مؤكد، ملغي، مكتمل
    
    # العلاقات
    user = db.relationship('User', backref=db.backref('appointments', lazy='dynamic', cascade='all, delete-orphan'))
    car = db.relationship('Car', backref=db.backref('appointments', lazy='dynamic', cascade='all, delete-orphan'))
    
    def __init__(self, car_id, name, email, phone, preferred_date, preferred_time, 
                 notes=None, user_id=None, status='مطلوب'):
        self.car_id = car_id
        self.name = name
        self.email = email
        self.phone = phone
        self.preferred_date = preferred_date
        self.preferred_time = preferred_time
        self.notes = notes
        self.user_id = user_id
        self.status = status
    
    def __repr__(self):
        return f'<Appointment {self.id} for Car {self.car_id}>'


class Article(db.Model):
    """نموذج بيانات المقالات"""
    __tablename__ = 'articles'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(256), nullable=False)
    content = db.Column(db.Text, nullable=False)
    author = db.Column(db.String(128), nullable=False)
    publish_date = db.Column(db.DateTime, default=datetime.utcnow)
    image_url = db.Column(db.String(256))
    category = db.Column(db.String(64))
    tags = db.Column(db.String(256))  # الوسوم مفصولة بفواصل
    
    def __init__(self, title, content, author, image_url=None, category=None, tags=None):
        self.title = title
        self.content = content
        self.author = author
        self.image_url = image_url
        self.category = category
        self.tags = tags
    
    def __repr__(self):
        return f'<Article {self.id}: {self.title}>'

