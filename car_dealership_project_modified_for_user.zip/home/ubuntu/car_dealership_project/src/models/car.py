from src.main import db
from datetime import datetime

class Brand(db.Model):
    """نموذج بيانات ماركات السيارات"""
    __tablename__ = 'brands'
    
    id = db.Column(db.Integer, primary_key=True)
    brand_name = db.Column(db.String(64), unique=True, index=True, nullable=False)
    brand_logo = db.Column(db.String(256))
    description = db.Column(db.Text)
    name = db.Column(db.String(64))  # للتوافق مع create_db.py
    name_en = db.Column(db.String(64))  # للتوافق مع create_db.py
    country = db.Column(db.String(64))  # للتوافق مع create_db.py
    logo = db.Column(db.String(256))  # للتوافق مع create_db.py
    
    # إزالة المُنشئ المخصص والاعتماد على المُنشئ الافتراضي لـ SQLAlchemy
    
    def __repr__(self):
        return f'<Brand {self.brand_name or self.name}>'


class Model(db.Model):
    """نموذج بيانات موديلات السيارات"""
    __tablename__ = 'models'
    
    id = db.Column(db.Integer, primary_key=True)
    brand_id = db.Column(db.Integer, db.ForeignKey('brands.id'), nullable=False)
    model_name = db.Column(db.String(64), index=True, nullable=False)
    category = db.Column(db.String(64), index=True)  # سيدان، SUV، إلخ
    description = db.Column(db.Text)
    
    # العلاقة مع الماركة
    brand = db.relationship('Brand', backref=db.backref('models', lazy='dynamic', cascade='all, delete-orphan'))
    
    def __init__(self, brand_id, model_name, category=None, description=None):
        self.brand_id = brand_id
        self.model_name = model_name
        self.category = category
        self.description = description
    
    def __repr__(self):
        return f'<Model {self.model_name}>'


class Car(db.Model):
    """نموذج بيانات السيارات"""
    __tablename__ = 'cars'
    
    id = db.Column(db.Integer, primary_key=True)
    model_id = db.Column(db.Integer, db.ForeignKey('models.id'), nullable=False)
    year = db.Column(db.Integer, index=True, nullable=False)
    price = db.Column(db.Float, index=True, nullable=False)
    mileage = db.Column(db.Float)
    color = db.Column(db.String(64))
    transmission = db.Column(db.String(64))  # أوتوماتيك، يدوي
    fuel_type = db.Column(db.String(64))  # بنزين، ديزل، كهرباء، هجين
    engine = db.Column(db.String(64))
    engine_size = db.Column(db.String(64))  # للتوافق مع create_db.py
    horsepower = db.Column(db.Integer)
    doors = db.Column(db.Integer)
    seats = db.Column(db.Integer)
    condition = db.Column(db.String(64), index=True, default='جديدة')  # جديدة، مستعملة، معتمدة
    features = db.Column(db.Text)  # ميزات السيارة مفصولة بفواصل
    description = db.Column(db.Text)
    availability = db.Column(db.String(64), default='متوفرة')  # متوفرة، محجوزة، مباعة
    is_available = db.Column(db.Boolean, default=True)  # للتوافق مع create_db.py
    location = db.Column(db.String(128))  # للتوافق مع create_db.py
    trim = db.Column(db.String(64))  # للتوافق مع create_db.py
    added_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_featured = db.Column(db.Boolean, default=False)
    is_special_offer = db.Column(db.Boolean, default=False)
    discount_amount = db.Column(db.Float, default=0)
    
    # العلاقة مع الموديل
    model = db.relationship('Model', backref=db.backref('cars', lazy='dynamic', cascade='all, delete-orphan'))
    
    def __init__(self, model_id, year, price, mileage=None, color=None, transmission=None,
                 fuel_type=None, engine=None, engine_size=None, horsepower=None, doors=None, seats=None,
                 condition='جديدة', features=None, description=None, availability='متوفرة',
                 is_featured=False, is_special_offer=False, discount_amount=0, is_available=True,
                 location=None, trim=None):
        self.model_id = model_id
        self.year = year
        self.price = price
        self.mileage = mileage
        self.color = color
        self.transmission = transmission
        self.fuel_type = fuel_type
        self.engine = engine
        self.engine_size = engine_size or engine  # استخدام engine إذا كان engine_size فارغاً
        self.horsepower = horsepower
        self.doors = doors
        self.seats = seats
        self.condition = condition
        self.features = features
        self.description = description
        self.availability = availability
        self.is_available = is_available
        self.location = location
        self.trim = trim
        self.is_featured = is_featured
        self.is_special_offer = is_special_offer
        self.discount_amount = discount_amount
        self.color = color
        self.transmission = transmission
        self.fuel_type = fuel_type
        self.engine = engine
        self.horsepower = horsepower
        self.doors = doors
        self.seats = seats
        self.condition = condition
        self.features = features
        self.description = description
        self.availability = availability
        self.is_featured = is_featured
        self.is_special_offer = is_special_offer
        self.discount_amount = discount_amount
    
    def get_primary_image(self):
        """الحصول على الصورة الرئيسية للسيارة"""
        primary_image = CarImage.query.filter_by(car_id=self.id, is_primary=True).first()
        if primary_image:
            return primary_image.image_url
        # إذا لم توجد صورة رئيسية، نعيد أول صورة
        first_image = CarImage.query.filter_by(car_id=self.id).first()
        if first_image:
            return first_image.image_url
        # إذا لم توجد أي صورة، نعيد صورة افتراضية
        return '/static/images/default_car.jpg'
    
    def get_final_price(self):
        """حساب السعر النهائي بعد الخصم إن وجد"""
        if self.is_special_offer and self.discount_amount > 0:
            return self.price - self.discount_amount
        return self.price
    
    def get_discount_percentage(self):
        """حساب نسبة الخصم"""
        if self.is_special_offer and self.discount_amount > 0 and self.price > 0:
            return (self.discount_amount / self.price) * 100
        return 0
    
    def __repr__(self):
        return f'<Car {self.id}: {self.model.brand.brand_name} {self.model.model_name} {self.year}>'


class CarImage(db.Model):
    """نموذج بيانات صور السيارات"""
    __tablename__ = 'car_images'
    
    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey('cars.id'), nullable=False)
    image_url = db.Column(db.String(256), nullable=False)
    is_primary = db.Column(db.Boolean, default=False)
    
    # العلاقة مع السيارة
    car = db.relationship('Car', backref=db.backref('images', lazy='dynamic', cascade='all, delete-orphan'))
    
    def __init__(self, car_id, image_url, is_primary=False):
        self.car_id = car_id
        self.image_url = image_url
        self.is_primary = is_primary
    
    def __repr__(self):
        return f'<CarImage {self.id} for Car {self.car_id}>'

