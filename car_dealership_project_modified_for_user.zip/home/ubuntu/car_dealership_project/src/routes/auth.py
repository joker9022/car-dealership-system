from flask import Blueprint, render_template, redirect, url_for, flash, request
from src.main import db, login_manager
from flask_login import login_user, logout_user, login_required, current_user

auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    """صفحة تسجيل الدخول"""
    # استيراد النماذج داخل الدالة لتجنب الاستيراد الدائري
    from src.models.user import User
    
    # إذا كان المستخدم مسجل دخوله بالفعل
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        user_input = request.form.get("username")
        password = request.form.get("password")
        remember = 'remember' in request.form
        
        user = User.query.filter((User.email == user_input) | (User.username == user_input)).first()
        
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('main.index'))
        else:
            flash('فشل تسجيل الدخول. يرجى التحقق من البريد الإلكتروني وكلمة المرور', 'danger')
    
    return render_template('login.html')

@auth.route('/register', methods=['GET', 'POST'])
def register():
    """صفحة التسجيل"""
    # استيراد النماذج داخل الدالة لتجنب الاستيراد الدائري
    from src.models.user import User
    
    # إذا كان المستخدم مسجل دخوله بالفعل
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # التحقق من البيانات
        if not username or not email or not password or not confirm_password:
            flash('يرجى ملء جميع الحقول المطلوبة', 'danger')
            return redirect(url_for('auth.register'))
        
        if password != confirm_password:
            flash('كلمات المرور غير متطابقة', 'danger')
            return redirect(url_for('auth.register'))
        
        # التحقق من عدم وجود مستخدم بنفس البريد الإلكتروني أو اسم المستخدم
        if User.query.filter_by(email=email).first():
            flash('البريد الإلكتروني مستخدم بالفعل', 'danger')
            return redirect(url_for('auth.register'))
        
        if User.query.filter_by(username=username).first():
            flash('اسم المستخدم مستخدم بالفعل', 'danger')
            return redirect(url_for('auth.register'))
        
        # إنشاء مستخدم جديد
        user = User(username=username, email=email, password=password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html')

@auth.route('/logout')
@login_required
def logout():
    """تسجيل الخروج"""
    logout_user()
    flash('تم تسجيل الخروج بنجاح', 'info')
    return redirect(url_for('main.index'))

@auth.route('/profile')
@login_required
def profile():
    """صفحة الملف الشخصي"""
    # استيراد النماذج داخل الدالة لتجنب الاستيراد الدائري
    from src.models.inquiry import Inquiry
    
    # الحصول على استفسارات المستخدم
    inquiries = Inquiry.query.filter_by(user_id=current_user.id).order_by(Inquiry.date_submitted.desc()).all()
    
    return render_template('auth/profile.html', inquiries=inquiries)

@auth.route("/forgot_password")
def forgot_password():
    """صفحة استعادة كلمة المرور"""
    return render_template("auth/forgot_password.html")




@auth.route("/favorites")
@login_required
def favorites():
    """صفحة السيارات المفضلة"""
    return render_template("auth/favorites.html")


