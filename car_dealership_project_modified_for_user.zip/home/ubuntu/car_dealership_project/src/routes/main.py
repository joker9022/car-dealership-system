from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from src.models.car import Brand, Model, Car
from src.models.inquiry import Article

main = Blueprint('main', __name__)

@main.route('/')
def index():
    """الصفحة الرئيسية"""
    # الحصول على السيارات المميزة
    featured_cars = Car.query.filter_by(is_featured=True).limit(6).all()
    
    # الحصول على أحدث السيارات
    latest_cars = Car.query.order_by(Car.added_date.desc()).limit(8).all()
    
    # الحصول على العروض الخاصة
    special_offers = Car.query.filter_by(is_special_offer=True).limit(4).all()
    
    # الحصول على أحدث المقالات
    latest_articles = Article.query.order_by(Article.publish_date.desc()).limit(3).all()
    
    return render_template('index.html', 
                           featured_cars=featured_cars,
                           latest_cars=latest_cars,
                           special_offers=special_offers,
                           latest_articles=latest_articles)

@main.route('/about')
def about():
    """صفحة عن المعرض"""
    return render_template('about.html')

@main.route('/contact', methods=['GET', 'POST'])
def contact():
    """صفحة الاتصال"""
    if request.method == 'POST':
        # معالجة نموذج الاتصال
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # هنا يمكن إضافة رمز لإرسال بريد إلكتروني أو حفظ الرسالة في قاعدة البيانات
        
        flash('تم إرسال رسالتك بنجاح. سنتواصل معك قريباً.', 'success')
        return redirect(url_for('main.contact'))
    
    return render_template('contact.html')

@main.route('/blog')
def blog():
    """صفحة المدونة"""
    page = request.args.get('page', 1, type=int)
    articles = Article.query.order_by(Article.publish_date.desc()).paginate(
        page=page, per_page=6, error_out=False)
    
    return render_template('blog.html', articles=articles)

@main.route('/blog/<int:article_id>')
def article(article_id):
    """صفحة مقال محدد"""
    article = Article.query.get_or_404(article_id)
    
    # الحصول على مقالات ذات صلة
    related_articles = Article.query.filter(
        Article.category == article.category,
        Article.id != article.id
    ).limit(3).all()
    
    return render_template('article.html', article=article, related_articles=related_articles)

@main.route('/faq')
def faq():
    """صفحة الأسئلة الشائعة"""
    return render_template('faq.html')

@main.route('/search')
def search():
    """صفحة البحث العامة"""
    query = request.args.get('q', '')
    
    # البحث في السيارات
    cars = Car.query.join(Model).join(Brand).filter(
        (Car.description.contains(query)) |
        (Model.model_name.contains(query)) |
        (Brand.brand_name.contains(query))
    ).all()
    
    # البحث في المقالات
    articles = Article.query.filter(
        (Article.title.contains(query)) |
        (Article.content.contains(query)) |
        (Article.tags.contains(query))
    ).all()
    
    return render_template('search_results.html', 
                           query=query, 
                           cars=cars, 
                           articles=articles)
