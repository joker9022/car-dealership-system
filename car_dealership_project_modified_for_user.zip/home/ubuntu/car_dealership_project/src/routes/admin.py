from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.car import Brand, Model, Car, CarImage
from src.models.inquiry import Inquiry, Appointment, Article
from src.main import db
import os

admin = Blueprint('admin', __name__)

# مسار وسيط للتحقق من صلاحيات المسؤول
@admin.before_request
def check_admin():
    if not current_user.is_authenticated or not current_user.is_admin:
        flash('ليس لديك صلاحية الوصول إلى هذه الصفحة.', 'danger')
        return redirect(url_for('main.index'))

@admin.route('/')
@login_required
def index():
    """لوحة تحكم المسؤول"""
    # إحصائيات عامة
    cars_count = Car.query.count()
    users_count = db.session.query(db.func.count(db.distinct(db.text('users.id')))).scalar()
    inquiries_count = Inquiry.query.filter_by(status='جديد').count()
    brands_count = Brand.query.count()
    
    # أحدث السيارات
    latest_cars = Car.query.order_by(Car.added_date.desc()).limit(5).all()
    
    # أحدث الاستفسارات
    latest_inquiries = Inquiry.query.order_by(Inquiry.date_submitted.desc()).limit(5).all()
    
    return render_template("admin/dashboard.html",
                           cars_count=cars_count,
                           users_count=users_count,
                           inquiries_count=inquiries_count,
                           brands_count=brands_count,
                           latest_cars=latest_cars,
                           latest_inquiries=latest_inquiries)

@admin.route('/cars')
@login_required
def cars():
    """إدارة السيارات"""
    page = request.args.get('page', 1, type=int)
    cars = Car.query.order_by(Car.added_date.desc()).paginate(page=page, per_page=10, error_out=False)
    return render_template('admin/cars.html', cars=cars)

@admin.route('/car/add', methods=['GET', 'POST'])
@login_required
def add_car():
    """إضافة سيارة جديدة"""
    brands = Brand.query.all()
    
    if request.method == 'POST':
        # الحصول على بيانات النموذج
        model_id = request.form.get('model_id', type=int)
        year = request.form.get('year', type=int)
        price = request.form.get('price', type=float)
        mileage = request.form.get('mileage', type=float)
        color = request.form.get('color')
        transmission = request.form.get('transmission')
        fuel_type = request.form.get('fuel_type')
        engine = request.form.get('engine')
        horsepower = request.form.get('horsepower', type=int)
        doors = request.form.get('doors', type=int)
        seats = request.form.get('seats', type=int)
        condition = request.form.get('condition')
        features = request.form.get('features')
        description = request.form.get('description')
        is_featured = True if request.form.get('is_featured') else False
        is_special_offer = True if request.form.get('is_special_offer') else False
        discount_amount = request.form.get('discount_amount', type=float, default=0)
        
        # التحقق من البيانات الأساسية
        if not all([model_id, year, price, condition]):
            flash('يرجى ملء جميع الحقول المطلوبة.', 'danger')
            return redirect(url_for('admin.add_car'))
        
        # إنشاء سيارة جديدة
        car = Car(
            model_id=model_id,
            year=year,
            price=price,
            mileage=mileage,
            color=color,
            transmission=transmission,
            fuel_type=fuel_type,
            engine=engine,
            horsepower=horsepower,
            doors=doors,
            seats=seats,
            condition=condition,
            features=features,
            description=description,
            is_featured=is_featured,
            is_special_offer=is_special_offer,
            discount_amount=discount_amount
        )
        
        db.session.add(car)
        db.session.commit()
        
        flash('تمت إضافة السيارة بنجاح.', 'success')
        return redirect(url_for('admin.cars'))
    
    return render_template('admin/add_car.html', brands=brands)

@admin.route('/car/edit/<int:car_id>', methods=['GET', 'POST'])
@login_required
def edit_car(car_id):
    """تعديل سيارة"""
    car = Car.query.get_or_404(car_id)
    brands = Brand.query.all()
    
    if request.method == 'POST':
        # الحصول على بيانات النموذج
        model_id = request.form.get('model_id', type=int)
        year = request.form.get('year', type=int)
        price = request.form.get('price', type=float)
        mileage = request.form.get('mileage', type=float)
        color = request.form.get('color')
        transmission = request.form.get('transmission')
        fuel_type = request.form.get('fuel_type')
        engine = request.form.get('engine')
        horsepower = request.form.get('horsepower', type=int)
        doors = request.form.get('doors', type=int)
        seats = request.form.get('seats', type=int)
        condition = request.form.get('condition')
        features = request.form.get('features')
        description = request.form.get('description')
        availability = request.form.get('availability')
        is_featured = True if request.form.get('is_featured') else False
        is_special_offer = True if request.form.get('is_special_offer') else False
        discount_amount = request.form.get('discount_amount', type=float, default=0)
        
        # التحقق من البيانات الأساسية
        if not all([model_id, year, price, condition, availability]):
            flash('يرجى ملء جميع الحقول المطلوبة.', 'danger')
            return redirect(url_for('admin.edit_car', car_id=car_id))
        
        # تحديث بيانات السيارة
        car.model_id = model_id
        car.year = year
        car.price = price
        car.mileage = mileage
        car.color = color
        car.transmission = transmission
        car.fuel_type = fuel_type
        car.engine = engine
        car.horsepower = horsepower
        car.doors = doors
        car.seats = seats
        car.condition = condition
        car.features = features
        car.description = description
        car.availability = availability
        car.is_featured = is_featured
        car.is_special_offer = is_special_offer
        car.discount_amount = discount_amount
        
        db.session.commit()
        
        flash('تم تحديث بيانات السيارة بنجاح.', 'success')
        return redirect(url_for('admin.cars'))
    
    return render_template('admin/edit_car.html', car=car, brands=brands)

@admin.route('/car/delete/<int:car_id>', methods=['POST'])
@login_required
def delete_car(car_id):
    """حذف سيارة"""
    car = Car.query.get_or_404(car_id)
    
    # حذف صور السيارة من الخادم
    for image in car.images:
        if os.path.exists(os.path.join('src/static', image.image_url.lstrip('/'))):
            os.remove(os.path.join('src/static', image.image_url.lstrip('/')))
    
    db.session.delete(car)
    db.session.commit()
    
    flash('تم حذف السيارة بنجاح.', 'success')
    return redirect(url_for('admin.cars'))

@admin.route('/inquiries')
@login_required
def inquiries():
    """إدارة الاستفسارات"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', 'all')
    
    query = Inquiry.query
    
    if status != 'all':
        query = query.filter_by(status=status)
    
    inquiries = query.order_by(Inquiry.date_submitted.desc()).paginate(page=page, per_page=10, error_out=False)
    
    return render_template('admin/inquiries.html', inquiries=inquiries, current_status=status)

@admin.route('/inquiry/<int:inquiry_id>', methods=['GET', 'POST'])
@login_required
def view_inquiry(inquiry_id):
    """عرض وتحديث استفسار"""
    inquiry = Inquiry.query.get_or_404(inquiry_id)
    
    if request.method == 'POST':
        status = request.form.get('status')
        
        inquiry.status = status
        db.session.commit()
        
        flash('تم تحديث حالة الاستفسار بنجاح.', 'success')
        return redirect(url_for('admin.inquiries'))
    
    return render_template('admin/view_inquiry.html', inquiry=inquiry)

@admin.route('/appointments')
@login_required
def appointments():
    """إدارة المواعيد"""
    page = request.args.get('page', 1, type=int)
    status = request.args.get('status', 'all')
    
    query = Appointment.query
    
    if status != 'all':
        query = query.filter_by(status=status)
    
    appointments = query.order_by(Appointment.preferred_date).paginate(page=page, per_page=10, error_out=False)
    
    return render_template('admin/appointments.html', appointments=appointments, current_status=status)

@admin.route('/appointment/<int:appointment_id>', methods=['GET', 'POST'])
@login_required
def view_appointment(appointment_id):
    """عرض وتحديث موعد"""
    appointment = Appointment.query.get_or_404(appointment_id)
    
    if request.method == 'POST':
        status = request.form.get('status')
        
        appointment.status = status
        db.session.commit()
        
        flash('تم تحديث حالة الموعد بنجاح.', 'success')
        return redirect(url_for('admin.appointments'))
    
    return render_template('admin/view_appointment.html', appointment=appointment)

@admin.route('/brands')
@login_required
def brands():
    """إدارة ماركات السيارات"""
    brands = Brand.query.all()
    return render_template('admin/brands.html', brands=brands)

@admin.route('/brand/add', methods=['GET', 'POST'])
@login_required
def add_brand():
    """إضافة ماركة جديدة"""
    if request.method == 'POST':
        brand_name = request.form.get('brand_name')
        name_en = request.form.get('name_en')
        country = request.form.get('country')
        description = request.form.get('description')
        
        # التحقق من عدم وجود ماركة بنفس الاسم
        existing_brand = Brand.query.filter_by(brand_name=brand_name).first()
        if existing_brand:
            flash('توجد ماركة بهذا الاسم بالفعل.', 'danger')
            return redirect(url_for('admin.add_brand'))
        
        # إنشاء ماركة جديدة
        brand = Brand(
            brand_name=brand_name,
            name=brand_name,
            name_en=name_en,
            country=country,
            description=description
        )
        db.session.add(brand)
        db.session.commit()
        
        flash('تمت إضافة الماركة بنجاح.', 'success')
        return redirect(url_for('admin.brands'))
    
    return render_template('admin/add_brand.html')

@admin.route('/models')
@login_required
def models():
    """إدارة موديلات السيارات"""
    models = Model.query.all()
    return render_template('admin/models.html', models=models)

@admin.route('/model/add', methods=['GET', 'POST'])
@login_required
def add_model():
    """إضافة موديل جديد"""
    brands = Brand.query.all()
    
    if request.method == 'POST':
        brand_id = request.form.get('brand_id', type=int)
        model_name = request.form.get('model_name')
        category = request.form.get('category')
        description = request.form.get('description')
        
        # التحقق من وجود الماركة
        brand = Brand.query.get(brand_id)
        if not brand:
            flash('الماركة المحددة غير موجودة.', 'danger')
            return redirect(url_for('admin.add_model'))
        
        # إنشاء موديل جديد
        model = Model(
            brand_id=brand_id,
            model_name=model_name,
            category=category,
            description=description
        )
        db.session.add(model)
        db.session.commit()
        
        flash('تمت إضافة الموديل بنجاح.', 'success')
        return redirect(url_for('admin.models'))
    
    return render_template('admin/add_model.html', brands=brands)

@admin.route('/articles')
@login_required
def articles():
    """إدارة المقالات"""
    page = request.args.get('page', 1, type=int)
    articles = Article.query.order_by(Article.publish_date.desc()).paginate(page=page, per_page=10, error_out=False)
    return render_template('admin/articles.html', articles=articles)

@admin.route('/article/add', methods=['GET', 'POST'])
@login_required
def add_article():
    """إضافة مقال جديد"""
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        author = request.form.get('author')
        category = request.form.get('category')
        tags = request.form.get('tags')
        
        # التحقق من البيانات الأساسية
        if not all([title, content, author]):
            flash('يرجى ملء جميع الحقول المطلوبة.', 'danger')
            return redirect(url_for('admin.add_article'))
        
        # إنشاء مقال جديد
        article = Article(
            title=title,
            content=content,
            author=author,
            category=category,
            tags=tags
        )
        db.session.add(article)
        db.session.commit()
        
        flash('تمت إضافة المقال بنجاح.', 'success')
        return redirect(url_for('admin.articles'))
    
    return render_template('admin/add_article.html')

@admin.route('/article/edit/<int:article_id>', methods=['GET', 'POST'])
@login_required
def edit_article(article_id):
    """تعديل مقال"""
    article = Article.query.get_or_404(article_id)
    
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        author = request.form.get('author')
        category = request.form.get('category')
        tags = request.form.get('tags')
        
        # التحقق من البيانات الأساسية
        if not all([title, content, author]):
            flash('يرجى ملء جميع الحقول المطلوبة.', 'danger')
            return redirect(url_for('admin.edit_article', article_id=article_id))
        
        # تحديث بيانات المقال
        article.title = title
        article.content = content
        article.author = author
        article.category = category
        article.tags = tags
        
        db.session.commit()
        
        flash('تم تحديث المقال بنجاح.', 'success')
        return redirect(url_for('admin.articles'))
    
    return render_template('admin/edit_article.html', article=article)


@admin.route('/update_settings', methods=['GET', 'POST'])
@login_required
def update_settings():
    """تحديث إعدادات الموقع"""
    if request.method == 'POST':
        # هنا ستتم معالجة بيانات النموذج لتحديث الإعدادات
        flash('تم تحديث الإعدادات بنجاح.', 'success')
        return redirect(url_for('admin.index'))
    return render_template('admin/settings.html')


