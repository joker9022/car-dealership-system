from flask import Blueprint, render_template, redirect, url_for, flash, request
from src.main import db

cars = Blueprint('cars', __name__)

@cars.route('/')
def browse():
    """صفحة تصفح السيارات"""
    # استيراد النماذج داخل الدالة لتجنب الاستيراد الدائري
    from src.models.car import Car, Brand, Model
    
    # الحصول على معايير التصفية
    brand_id = request.args.get('brand', type=int)
    model_id = request.args.get('model', type=int)
    year = request.args.get('year', type=int)
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    
    # بناء الاستعلام
    query = Car.query
    
    if brand_id:
        query = query.filter_by(brand_id=brand_id)
    if model_id:
        query = query.filter_by(model_id=model_id)
    if year:
        query = query.filter_by(year=year)
    if min_price:
        query = query.filter(Car.price >= min_price)
    if max_price:
        query = query.filter(Car.price <= max_price)
    
    # ترتيب النتائج
    sort_by = request.args.get('sort', 'newest')
    if sort_by == 'price_asc':
        query = query.order_by(Car.price.asc())
    elif sort_by == 'price_desc':
        query = query.order_by(Car.price.desc())
    else:  # newest
        query = query.order_by(Car.added_date.desc())
    
    # تقسيم الصفحات
    page = request.args.get('page', 1, type=int)
    cars = query.paginate(page=page, per_page=12)
    
    # الحصول على جميع الماركات والموديلات للفلتر
    brands = Brand.query.all()
    
    return render_template('cars/browse.html', 
                          cars=cars,
                          brands=brands,
                          current_brand=brand_id,
                          current_model=model_id,
                          current_year=year,
                          current_min_price=min_price,
                          current_max_price=max_price,
                          current_sort=sort_by)

@cars.route('/<int:car_id>')
def details(car_id):
    """صفحة تفاصيل السيارة"""
    # استيراد النماذج داخل الدالة لتجنب الاستيراد الدائري
    from src.models.car import Car
    from src.models.inquiry import Inquiry
    
    car = Car.query.get_or_404(car_id)
    
    # الحصول على سيارات مشابهة
    similar_cars = Car.query.filter(Car.model_id == car.model_id, Car.id != car.id).limit(4).all()
    
    return render_template("cars/detail.html", car=car, similar_cars=similar_cars)

@cars.route('/<int:car_id>/inquiry', methods=['GET', 'POST'])
def inquiry(car_id):
    """صفحة إرسال استفسار عن سيارة"""
    # استيراد النماذج داخل الدالة لتجنب الاستيراد الدائري
    from src.models.car import Car
    from src.models.inquiry import Inquiry
    from flask_login import current_user
    
    car = Car.query.get_or_404(car_id)
    
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        message = request.form.get('message')
        
        # التحقق من البيانات
        if not name or not email or not phone or not message:
            flash('يرجى ملء جميع الحقول المطلوبة', 'danger')
            return redirect(url_for('cars.inquiry', car_id=car_id))
        
        # إنشاء استفسار جديد
        user_id = current_user.id if current_user.is_authenticated else None
        inquiry = Inquiry(car_id=car_id, name=name, email=email, phone=phone, message=message, user_id=user_id)
        
        db.session.add(inquiry)
        db.session.commit()
        
        flash('تم إرسال استفسارك بنجاح، سنتواصل معك قريباً', 'success')
        return redirect(url_for('cars.details', car_id=car_id))
    
    return render_template('cars/inquiry.html', car=car)