// تهيئة جميع الأنظمة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    // تأخير قصير للتأكد من تحميل جميع العناصر
    // setTimeout(() => {
        // window.financeCalc = new FinanceCalculator();
        // window.carRating = new CarRatingSystem();
        // window.carComparison = new CarComparisonSystem();
        // window.advancedSearch = new AdvancedSearchSystem();
    // }, 1000);
});


