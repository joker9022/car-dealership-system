// إدارة الوضع المظلم
class ThemeManager {
    constructor() {
        this.theme = localStorage.getItem('theme') || 'light';
        this.init();
    }

    init() {
        this.applyTheme();
        this.setupToggleButton();
    }

    applyTheme() {
        document.documentElement.setAttribute('data-theme', this.theme);
        document.body.classList.toggle('dark-mode', this.theme === 'dark');
        
        // تحديث أيقونة الزر
        const themeIcon = document.querySelector('#theme-toggle i');
        if (themeIcon) {
            themeIcon.className = this.theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    toggleTheme() {
        this.theme = this.theme === 'light' ? 'dark' : 'light';
        localStorage.setItem('theme', this.theme);
        this.applyTheme();
    }

    setupToggleButton() {
        const toggleButton = document.getElementById('theme-toggle');
        if (toggleButton) {
            toggleButton.addEventListener('click', () => this.toggleTheme());
        }
    }
}

// إدارة اللغة
class LanguageManager {
    constructor() {
        this.currentLang = localStorage.getItem('language') || 'ar';
        this.init();
    }

    init() {
        this.applyLanguage();
        this.setupLanguageSelector();
    }

    applyLanguage() {
        document.documentElement.setAttribute('lang', this.currentLang);
        document.documentElement.setAttribute('dir', this.currentLang === 'ar' ? 'rtl' : 'ltr');
        
        // تحديث النصوص حسب اللغة
        this.updateTexts();
    }

    updateTexts() {
        const translations = {
            ar: {
                'site-title': 'معرض السيارات',
                'home': 'الرئيسية',
                'cars': 'السيارات',
                'about': 'عن المعرض',
                'contact': 'اتصل بنا',
                'faq': 'الأسئلة الشائعة',
                'search-placeholder': 'بحث...',
                'login': 'تسجيل الدخول',
                'register': 'إنشاء حساب'
            },
            en: {
                'site-title': 'Car Dealership',
                'home': 'Home',
                'cars': 'Cars',
                'about': 'About',
                'contact': 'Contact',
                'faq': 'FAQ',
                'search-placeholder': 'Search...',
                'login': 'Login',
                'register': 'Register'
            }
        };

        const texts = translations[this.currentLang];
        Object.keys(texts).forEach(key => {
            const element = document.querySelector(`[data-translate="${key}"]`);
            if (element) {
                element.textContent = texts[key];
            }
        });

        // تحديث placeholder للبحث
        const searchInput = document.querySelector('input[placeholder]');
        if (searchInput && texts['search-placeholder']) {
            searchInput.placeholder = texts['search-placeholder'];
        }
    }

    changeLanguage(lang) {
        this.currentLang = lang;
        localStorage.setItem('language', lang);
        this.applyLanguage();
        
        // إعادة تحميل الصفحة لتطبيق التغييرات الكاملة
        window.location.reload();
    }

    setupLanguageSelector() {
        const langSelector = document.getElementById('language-selector');
        if (langSelector) {
            langSelector.addEventListener('change', (e) => {
                this.changeLanguage(e.target.value);
            });
            langSelector.value = this.currentLang;
        }
    }
}

// إدارة الألوان
class ColorManager {
    constructor() {
        this.primaryColor = localStorage.getItem('primary-color') || '#007bff';
        this.init();
    }

    init() {
        this.applyColors();
        this.setupColorPicker();
    }

    applyColors() {
        document.documentElement.style.setProperty('--primary-color', this.primaryColor);
        document.documentElement.style.setProperty('--primary-hover', this.adjustBrightness(this.primaryColor, -20));
    }

    adjustBrightness(hex, percent) {
        const num = parseInt(hex.replace("#", ""), 16);
        const amt = Math.round(2.55 * percent);
        const R = (num >> 16) + amt;
        const G = (num >> 8 & 0x00FF) + amt;
        const B = (num & 0x0000FF) + amt;
        return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
            (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
            (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
    }

    changeColor(color) {
        this.primaryColor = color;
        localStorage.setItem('primary-color', color);
        this.applyColors();
    }

    setupColorPicker() {
        const colorPicker = document.getElementById('color-picker');
        if (colorPicker) {
            colorPicker.value = this.primaryColor;
            colorPicker.addEventListener('change', (e) => {
                this.changeColor(e.target.value);
            });
        }
    }
}

// تهيئة المدراء عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    new ThemeManager();
    new LanguageManager();
    new ColorManager();
});

// إضافة تأثيرات تفاعلية
document.addEventListener('DOMContentLoaded', function() {
    // تأثير التمرير السلس
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // تأثير الظهور عند التمرير
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);

    document.querySelectorAll('.card, .feature-item').forEach(el => {
        observer.observe(el);
    });

    // تحسين تجربة النماذج
    document.querySelectorAll('input, textarea, select').forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });
    });
});

