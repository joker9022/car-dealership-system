import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.main import app, db
from src.models.user import User
from src.models.car import Brand, Model, Car, CarImage
from src.models.inquiry import Inquiry
from datetime import datetime

def create_sample_data():
    """إنشاء بيانات تجريبية للموقع"""
    
    print("🚀 بدء إنشاء البيانات التجريبية...")
    
    try:
        # إنشاء مستخدم مسؤول
        print("👤 إنشاء حساب المسؤول...")
        admin = User(
            username='admin',
            email='admin@cardealership-benghazi.ly',
            password='admin123',
            is_admin=True,
            first_name='مدير',
            last_name='النظام',
            phone_number='+218912345678',
            city='بنغازي'
        )
        db.session.add(admin)
        
        # إنشاء مستخدم عادي للاختبار
        test_user = User(
            username='testuser',
            email='test@example.com',
            password='test123',
            first_name='أحمد',
            last_name='محمد',
            phone_number='+218913456789',
            city='بنغازي'
        )
        db.session.add(test_user)
        
        # إنشاء العلامات التجارية
        print("🏷️ إنشاء العلامات التجارية...")
        brands_data = [
            {'name': 'تويوتا', 'name_en': 'Toyota', 'country': 'اليابان', 'logo': 'toyota-logo.png'},
            {'name': 'نيسان', 'name_en': 'Nissan', 'country': 'اليابان', 'logo': 'nissan-logo.png'},
            {'name': 'هيونداي', 'name_en': 'Hyundai', 'country': 'كوريا الجنوبية', 'logo': 'hyundai-logo.png'},
            {'name': 'كيا', 'name_en': 'Kia', 'country': 'كوريا الجنوبية', 'logo': 'kia-logo.png'},
            {'name': 'هوندا', 'name_en': 'Honda', 'country': 'اليابان', 'logo': 'honda-logo.png'},
            {'name': 'فولكس فاجن', 'name_en': 'Volkswagen', 'country': 'ألمانيا', 'logo': 'vw-logo.png'},
            {'name': 'بي إم دبليو', 'name_en': 'BMW', 'country': 'ألمانيا', 'logo': 'bmw-logo.png'},
            {'name': 'مرسيدس بنز', 'name_en': 'Mercedes-Benz', 'country': 'ألمانيا', 'logo': 'mercedes-logo.png'},
            {'name': 'أودي', 'name_en': 'Audi', 'country': 'ألمانيا', 'logo': 'audi-logo.png'},
            {'name': 'فورد', 'name_en': 'Ford', 'country': 'الولايات المتحدة', 'logo': 'ford-logo.png'},
            {'name': 'شيفروليه', 'name_en': 'Chevrolet', 'country': 'الولايات المتحدة', 'logo': 'chevrolet-logo.png'},
            {'name': 'مازدا', 'name_en': 'Mazda', 'country': 'اليابان', 'logo': 'mazda-logo.png'},
            {'name': 'سوبارو', 'name_en': 'Subaru', 'country': 'اليابان', 'logo': 'subaru-logo.png'},
            {'name': 'ميتسوبيشي', 'name_en': 'Mitsubishi', 'country': 'اليابان', 'logo': 'mitsubishi-logo.png'},
            {'name': 'سوزوكي', 'name_en': 'Suzuki', 'country': 'اليابان', 'logo': 'suzuki-logo.png'},
        ]
        
        brands = {}
        for brand_data in brands_data:
            # إنشاء كائن Brand مباشرة بالحقول المطلوبة فقط دون تمرير 'name'
            brand = Brand(
                brand_name=brand_data['name'],
                brand_logo=brand_data['logo'],
                description=f"علامة تجارية رائدة في صناعة السيارات من {brand_data['country']}",
                name_en=brand_data['name_en'],
                country=brand_data['country'],
                logo=brand_data['logo']
            )
            db.session.add(brand)
            brands[brand_data['name_en']] = brand
        
        db.session.flush()  # للحصول على معرفات العلامات التجارية
        
        # إنشاء الموديلات لعام 2025
        print("🚙 إنشاء موديلات السيارات لعام 2025...")
        models_data = [
            # تويوتا
            {'brand': 'Toyota', 'name': 'كامري', 'name_en': 'Camry', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Toyota', 'name': 'كورولا', 'name_en': 'Corolla', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Toyota', 'name': 'راف 4', 'name_en': 'RAV4', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Toyota', 'name': 'هايلاندر', 'name_en': 'Highlander', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Toyota', 'name': 'برادو', 'name_en': 'Prado', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Toyota', 'name': 'لاند كروزر', 'name_en': 'Land Cruiser', 'year': 2025, 'type': 'SUV'},
            
            # نيسان
            {'brand': 'Nissan', 'name': 'التيما', 'name_en': 'Altima', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Nissan', 'name': 'سنترا', 'name_en': 'Sentra', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Nissan', 'name': 'روج', 'name_en': 'Rogue', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Nissan', 'name': 'مورانو', 'name_en': 'Murano', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Nissan', 'name': 'باثفايندر', 'name_en': 'Pathfinder', 'year': 2025, 'type': 'SUV'},
            
            # هيونداي
            {'brand': 'Hyundai', 'name': 'إلنترا', 'name_en': 'Elantra', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Hyundai', 'name': 'سوناتا', 'name_en': 'Sonata', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Hyundai', 'name': 'توكسون', 'name_en': 'Tucson', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Hyundai', 'name': 'سانتا في', 'name_en': 'Santa Fe', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Hyundai', 'name': 'كونا', 'name_en': 'Kona', 'year': 2025, 'type': 'SUV'},
            
            # كيا
            {'brand': 'Kia', 'name': 'أوبتيما', 'name_en': 'Optima', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Kia', 'name': 'فورتي', 'name_en': 'Forte', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Kia', 'name': 'سبورتاج', 'name_en': 'Sportage', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Kia', 'name': 'سورينتو', 'name_en': 'Sorento', 'year': 2025, 'type': 'SUV'},
            
            # بي إم دبليو
            {'brand': 'BMW', 'name': '3 سيريز', 'name_en': '3 Series', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'BMW', 'name': '5 سيريز', 'name_en': '5 Series', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'BMW', 'name': 'X3', 'name_en': 'X3', 'year': 2025, 'type': 'SUV'},
            {'brand': 'BMW', 'name': 'X5', 'name_en': 'X5', 'year': 2025, 'type': 'SUV'},
            
            # مرسيدس بنز
            {'brand': 'Mercedes-Benz', 'name': 'C كلاس', 'name_en': 'C-Class', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Mercedes-Benz', 'name': 'E كلاس', 'name_en': 'E-Class', 'year': 2025, 'type': 'سيدان'},
            {'brand': 'Mercedes-Benz', 'name': 'GLC', 'name_en': 'GLC', 'year': 2025, 'type': 'SUV'},
            {'brand': 'Mercedes-Benz', 'name': 'GLE', 'name_en': 'GLE', 'year': 2025, 'type': 'SUV'},
        ]
        
        models = {}
        for model_data in models_data:
            model = Model(
                model_name=model_data['name'],  # تغيير name إلى model_name
                brand_id=brands[model_data['brand']].id,
                category=model_data['type']  # تغيير body_type إلى category
            )
            db.session.add(model)
            models[f"{model_data['brand']}_{model_data['name_en']}"] = model
        
        db.session.flush()  # للحصول على معرفات الموديلات
        
        # إنشاء السيارات
        print("🚗 إنشاء السيارات...")
        cars_data = [
            {
                'model_key': 'Toyota_Camry',
                'trim': 'LE',
                'price': 145000,  # دينار ليبي
                'mileage': 0,
                'condition': 'جديدة',
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'engine_size': '2.5L',
                'color': 'أبيض لؤلؤي',
                'features': 'نظام ملاحة، كاميرا خلفية، مقاعد جلدية، نظام صوتي متطور',
                'description': 'تويوتا كامري 2025 الجديدة كلياً بتصميم عصري ومحرك قوي واقتصادي في استهلاك الوقود',
                'is_featured': True,
                'is_available': True,
                'location': 'بنغازي'
            },
            {
                'model_key': 'Toyota_RAV4',
                'trim': 'XLE',
                'price': 165000,
                'mileage': 0,
                'condition': 'جديدة',
                'fuel_type': 'هايبرد',
                'transmission': 'أوتوماتيك',
                'engine_size': '2.5L Hybrid',
                'color': 'أزرق معدني',
                'features': 'دفع رباعي، نظام هايبرد، شاشة لمس 8 بوصة، نظام أمان تويوتا',
                'description': 'تويوتا راف 4 هايبرد 2025 - SUV متوسط الحجم بتقنية هايبرد متطورة',
                'is_featured': True,
                'is_available': True,
                'location': 'بنغازي'
            },
            {
                'model_key': 'BMW_X5',
                'trim': 'xDrive40i',
                'price': 320000,
                'mileage': 0,
                'condition': 'جديدة',
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'engine_size': '3.0L TwinPower Turbo',
                'color': 'أسود',
                'features': 'دفع رباعي، مقاعد جلدية، نظام صوتي Harman Kardon، شاشة iDrive',
                'description': 'بي إم دبليو X5 2025 - SUV فاخر بأداء استثنائي وتقنيات متقدمة',
                'is_featured': True,
                'is_available': True,
                'location': 'بنغازي'
            },
            {
                'model_key': 'Hyundai_Tucson',
                'trim': 'SEL',
                'price': 125000,
                'mileage': 0,
                'condition': 'جديدة',
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'engine_size': '2.5L',
                'color': 'فضي',
                'features': 'شاشة لمس، كاميرا خلفية، مقاعد مدفأة، نظام أمان SmartSense',
                'description': 'هيونداي توكسون 2025 - SUV عملي وأنيق بتصميم جديد ومواصفات متطورة',
                'is_featured': False,
                'is_available': True,
                'location': 'بنغازي'
            },
            {
                'model_key': 'Nissan_Altima',
                'trim': 'SV',
                'price': 135000,
                'mileage': 0,
                'condition': 'جديدة',
                'fuel_type': 'بنزين',
                'transmission': 'CVT',
                'engine_size': '2.5L',
                'color': 'أحمر',
                'features': 'نظام ProPILOT Assist، شاشة 8 بوصة، مقاعد Zero Gravity',
                'description': 'نيسان التيما 2025 - سيدان متوسطة بتقنيات ذكية ومحرك اقتصادي',
                'is_featured': False,
                'is_available': True,
                'location': 'بنغازي'
            },
            {
                'model_key': 'Mercedes-Benz_C-Class',
                'trim': 'C 300',
                'price': 280000,
                'mileage': 0,
                'condition': 'جديدة',
                'fuel_type': 'بنزين',
                'transmission': '9G-TRONIC',
                'engine_size': '2.0L Turbo',
                'color': 'أبيض',
                'features': 'نظام MBUX، مقاعد جلدية، نظام صوتي Burmester، نظام أمان متطور',
                'description': 'مرسيدس بنز C كلاس 2025 - سيدان فاخرة بتصميم أنيق وتقنيات متقدمة',
                'is_featured': True,
                'is_available': True,
                'location': 'بنغازي'
            },
            # سيارات مستعملة
            {
                'model_key': 'Toyota_Corolla',
                'trim': 'LE',
                'price': 85000,
                'mileage': 45000,
                'condition': 'مستعملة',
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'engine_size': '1.8L',
                'color': 'رمادي',
                'features': 'كاميرا خلفية، شاشة لمس، مقاعد قماشية، نظام أمان Toyota Safety Sense',
                'description': 'تويوتا كورولا 2023 مستعملة بحالة ممتازة وصيانة منتظمة',
                'is_featured': False,
                'is_available': True,
                'location': 'بنغازي'
            },
            {
                'model_key': 'Hyundai_Elantra',
                'trim': 'SEL',
                'price': 75000,
                'mileage': 32000,
                'condition': 'مستعملة',
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'engine_size': '2.0L',
                'color': 'أزرق',
                'features': 'شاشة لمس، بلوتوث، مقاعد مدفأة، نظام أمان SmartSense',
                'description': 'هيونداي إلنترا 2023 مستعملة بحالة جيدة جداً وسعر مناسب',
                'is_featured': False,
                'is_available': True,
                'location': 'بنغازي'
            }
        ]
        
        for car_data in cars_data:
            model_key = car_data['model_key']
            if model_key in models:
                car = Car(
                    model_id=models[model_key].id,
                    trim=car_data['trim'],
                    price=car_data['price'],
                    mileage=car_data['mileage'],
                    condition=car_data['condition'],
                    fuel_type=car_data['fuel_type'],
                    transmission=car_data['transmission'],
                    engine_size=car_data['engine_size'],
                    color=car_data['color'],
                    features=car_data['features'],
                    description=car_data['description'],
                    is_featured=car_data['is_featured'],
                    is_available=car_data['is_available'],
                    location=car_data['location'],
                    year=2025 if car_data['condition'] == 'جديدة' else 2023
                )
                db.session.add(car)
        
        # إنشاء استفسارات تجريبية
        print("📧 إنشاء استفسارات تجريبية...")
        # الحصول على معرفات السيارات الموجودة لاستخدامها في الاستفسارات
        cars = Car.query.all()
        if not cars:
            print("⚠️ لا توجد سيارات لربط الاستفسارات بها. سيتم تخطي إنشاء الاستفسارات.")
        else:
            # استخدام معرفات السيارات الموجودة فعلياً
            car_ids = [car.id for car in cars]
            
            inquiries_data = [
                {
                    'name': 'محمد أحمد',
                    'email': 'mohammed@example.com',
                    'phone': '+218913456789',
                    'subject': 'استفسار عن تويوتا كامري 2025',
                    'message': 'أرغب في معرفة المزيد عن مواصفات وأسعار تويوتا كامري 2025. هل يمكن ترتيب موعد لمعاينة السيارة؟',
                    'status': 'جديد',
                    'car_id': car_ids[0] if len(car_ids) > 0 else None  # استخدام أول سيارة
                },
                {
                    'name': 'فاطمة علي',
                    'email': 'fatima@example.com',
                    'phone': '+218914567890',
                    'subject': 'استفسار عن التمويل',
                    'message': 'هل تقدمون خدمات التمويل لشراء السيارات؟ وما هي الشروط والأوراق المطلوبة؟',
                    'status': 'قيد المراجعة',
                    'car_id': car_ids[1] if len(car_ids) > 1 else car_ids[0] if len(car_ids) > 0 else None  # استخدام ثاني سيارة أو الأولى
                },
                {
                    'name': 'عبد الله محمد',
                    'email': 'abdullah@example.com',
                    'phone': '+218915678901',
                    'subject': 'بيع سيارة',
                    'message': 'لدي سيارة نيسان التيما 2020 أرغب في بيعها. هل تقبلون شراء السيارات المستعملة؟',
                    'status': 'مكتمل',
                    'car_id': car_ids[2] if len(car_ids) > 2 else car_ids[0] if len(car_ids) > 0 else None  # استخدام ثالث سيارة أو الأولى
                }
        ]
        
        for inquiry_data in inquiries_data:
            inquiry = Inquiry(
                name=inquiry_data['name'],
                email=inquiry_data['email'],
                phone=inquiry_data['phone'],
                subject=inquiry_data['subject'],
                message=inquiry_data['message'],
                status=inquiry_data['status'],
                car_id=inquiry_data['car_id']  # إضافة car_id
            )
            db.session.add(inquiry)
        
        # حفظ جميع البيانات
        db.session.commit()
        print("✅ تم إنشاء جميع البيانات التجريبية بنجاح!")
        
        # طباعة ملخص البيانات المنشأة
        print("\n📊 ملخص البيانات المنشأة:")
        print(f"👥 المستخدمين: {User.query.count()}")
        print(f"🏷️ العلامات التجارية: {Brand.query.count()}")
        print(f"🚙 الموديلات: {Model.query.count()}")
        print(f"🚗 السيارات: {Car.query.count()}")
        print(f"📧 الاستفسارات: {Inquiry.query.count()}")
        
        print("\n🔑 بيانات تسجيل الدخول:")
        print("المسؤول:")
        print("  اسم المستخدم: admin")
        print("  كلمة المرور: admin123")
        print("\nمستخدم تجريبي:")
        print("  اسم المستخدم: testuser")
        print("  كلمة المرور: test123")
        
    except Exception as e:
        print(f"❌ خطأ في إنشاء البيانات: {str(e)}")
        db.session.rollback()
        raise

def main():
    """الدالة الرئيسية لإنشاء قاعدة البيانات"""
    print("🗄️ بدء إنشاء قاعدة البيانات...")
    
    with app.app_context():
        try:
            # حذف الجداول الموجودة وإنشاؤها من جديد
            print("🔄 إعادة إنشاء الجداول...")
            db.drop_all()
            db.create_all()
            print("✅ تم إنشاء الجداول بنجاح!")
            
            # إنشاء البيانات التجريبية
            create_sample_data()
            
            print("\n🎉 تم إنشاء قاعدة البيانات بنجاح!")
            print("🌐 يمكنك الآن تشغيل التطبيق باستخدام: python run.py")
            
        except Exception as e:
            print(f"❌ فشل في إنشاء قاعدة البيانات: {str(e)}")
            return False
    
    return True

if __name__ == '__main__':
    success = main()
    if not success:
        sys.exit(1)

