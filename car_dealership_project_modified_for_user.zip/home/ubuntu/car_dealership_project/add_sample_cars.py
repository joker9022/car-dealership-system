import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.main import app, db
from src.models.car import Car, Brand, Model

def add_sample_cars():
    with app.app_context():
        # إضافة علامات تجارية إضافية
        brands_data = [
            {'name': 'تويوتا', 'name_en': 'Toyota', 'country': 'اليابان', 'brand_name': 'تويوتا'},
            {'name': 'نيسان', 'name_en': 'Nissan', 'country': 'اليابان', 'brand_name': 'نيسان'},
            {'name': 'هوندا', 'name_en': 'Honda', 'country': 'اليابان', 'brand_name': 'هوندا'},
        ]
        
        for brand_data in brands_data:
            existing_brand = Brand.query.filter_by(brand_name=brand_data['brand_name']).first()
            if not existing_brand:
                brand = Brand()
                for key, value in brand_data.items():
                    setattr(brand, key, value)
                db.session.add(brand)
        
        db.session.commit()
        
        # الحصول على معرفات العلامات التجارية
        toyota_brand = Brand.query.filter_by(brand_name='تويوتا').first()
        nissan_brand = Brand.query.filter_by(brand_name='نيسان').first()
        honda_brand = Brand.query.filter_by(brand_name='هوندا').first()
        
        # إضافة موديلات
        models_data = [
            {'brand_id': toyota_brand.id, 'model_name': 'كامري', 'category': 'سيدان'},
            {'brand_id': nissan_brand.id, 'model_name': 'التيما', 'category': 'سيدان'},
            {'brand_id': honda_brand.id, 'model_name': 'سيفيك', 'category': 'سيدان'},
        ]
        
        for model_data in models_data:
            existing_model = Model.query.filter_by(model_name=model_data['model_name']).first()
            if not existing_model:
                model = Model(**model_data)
                db.session.add(model)
        
        db.session.commit()
        
        # الحصول على معرفات الموديلات
        camry_model = Model.query.filter_by(model_name='كامري').first()
        altima_model = Model.query.filter_by(model_name='التيما').first()
        civic_model = Model.query.filter_by(model_name='سيفيك').first()
        
        # إضافة سيارات تجريبية
        cars_data = [
            {
                'model_id': camry_model.id,
                'year': 2023,
                'price': 45000,
                'mileage': 15000,
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'color': 'فضي',
                'condition': 'مستعمل',
                'features': 'مكيف هواء، نظام ملاحة، كاميرا خلفية، مقاعد جلدية',
                'description': 'سيارة سيدان فاخرة بمحرك قوي واقتصادي في استهلاك الوقود',
                'doors': 4,
                'seats': 5
            },
            {
                'model_id': altima_model.id,
                'year': 2022,
                'price': 38000,
                'mileage': 25000,
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'color': 'أبيض',
                'condition': 'مستعمل',
                'features': 'شاشة لمس، بلوتوث، مثبت سرعة، فرامل ABS',
                'description': 'سيارة عائلية مريحة مع تقنيات حديثة ونظام أمان متطور',
                'doors': 4,
                'seats': 5
            },
            {
                'model_id': civic_model.id,
                'year': 2024,
                'price': 52000,
                'mileage': 5000,
                'fuel_type': 'بنزين',
                'transmission': 'أوتوماتيك',
                'color': 'أزرق',
                'condition': 'شبه جديد',
                'features': 'نظام هوندا الذكي، شاحن لاسلكي، مقاعد رياضية، إضاءة LED',
                'description': 'سيارة رياضية أنيقة بتصميم عصري وأداء ممتاز',
                'doors': 4,
                'seats': 5
            }
        ]
        
        for car_data in cars_data:
            existing_car = Car.query.filter_by(
                model_id=car_data['model_id'], 
                year=car_data['year'], 
                color=car_data['color']
            ).first()
            if not existing_car:
                car = Car(**car_data)
                db.session.add(car)
        
        db.session.commit()
        print("تم إضافة السيارات التجريبية بنجاح!")

if __name__ == '__main__':
    add_sample_cars()

